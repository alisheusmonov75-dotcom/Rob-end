"""Loads and saves high scores to a small JSON file next to the game."""
import json
import os
from settings import HIGHSCORE_FILE, MAX_HIGHSCORES


def _path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), HIGHSCORE_FILE)


def load_highscores():
    path = _path()
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r") as f:
            data = json.load(f)
        if isinstance(data, list):
            return sorted((int(s) for s in data), reverse=True)[:MAX_HIGHSCORES]
    except (json.JSONDecodeError, OSError, ValueError, TypeError):
        pass
    return []


def save_highscore(score):
    scores = load_highscores()
    scores.append(score)
    scores = sorted(scores, reverse=True)[:MAX_HIGHSCORES]
    try:
        with open(_path(), "w") as f:
            json.dump(scores, f)
    except OSError:
        pass
    return scores

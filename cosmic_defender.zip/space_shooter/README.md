# Cosmic Defender 🚀

Pygame'da yozilgan to'liq fazoviy otishma (space shooter) o'yini. To'lqinlab keladigan dushmanlar, kuchaytirgichlar (power-up), boss janglari, zarrachali portlash effektlari va rekordlar jadvali bilan.

## O'rnatish

1. Python 3.9+ kerak (`python3 --version` bilan tekshiring).
2. Kutubxonalarni o'rnating:

   ```bash
   pip install -r requirements.txt
   ```

   - `pygame` — o'yin uchun shart.
   - `numpy` — ixtiyoriy; o'rnatilsa, barcha tovush effektlari kodning ichida avtomatik generatsiya qilinadi (tashqi audio fayl kerak emas). O'rnatilmasa, o'yin ovozsiz ishlayveradi, xatolik bermaydi.

## Ishga tushirish

```bash
python main.py
```

## Boshqaruv

| Tugma | Amal |
|---|---|
| ← → ↑ ↓ yoki WASD | Kemani harakatlantirish |
| BO'SHLIQ (Space) | Otish (bosib turing — avtomatik ketma-ket otadi) |
| P yoki ESC | Pauza |
| ENTER | Boshlash / qayta boshlash |
| ESC (menyu/tugagan holatda) | Chiqish |

## O'yin xususiyatlari

- **4 turdagi dushman**: oddiy, zigzag harakatlanuvchi, tez uchuvchi va har 5-to'lqinda paydo bo'ladigan **boss**.
- **5 xil kuchaytirgich**: jon to'ldirish, tez otish, uch tomonlama otish, himoya qalqoni, tezlik oshirish.
- To'lqin ortgan sari qiyinlashadigan **progressiv qiyinchilik**.
- Portlash va zarba effektlari uchun **zarracha (particle) tizimi**.
- Uch qatlamli **parallaks yulduzli fon**.
- **Diskka saqlanadigan rekordlar** (`highscores.json` fayliga, o'yin papkasida avtomatik yaraladi).
- Kodning o'zida generatsiya qilinadigan **tovush effektlari** (tashqi fayl kerak emas).

## Loyiha tuzilishi

```
space_shooter/
├── main.py           # O'yin sikli va holatlar (menyu/o'yin/pauza/tugadi)
├── settings.py        # Barcha sozlanadigan raqamlar (tezlik, o'lcham, ranglar...)
├── player.py           # O'yinchi kemasi: harakat, otish, kuchaytirgichlar
├── enemy.py             # Dushman turlari va boss
├── bullet.py             # O'q (snaryad) klassi
├── powerup.py             # Kuchaytirgichlar
├── particles.py            # Portlash zarrachalari
├── background.py            # Parallaks yulduzli fon
├── sound_manager.py          # numpy bilan generatsiya qilingan tovushlar
├── ui.py                       # HUD (jon, ball, to'lqin ko'rsatkichlari)
├── highscores.py                 # Rekordlarni saqlash/o'qish
└── requirements.txt
```

Har bir fayl bitta narsaga javobgar — shuning uchun o'zgartirish yoki yangi funksiya qo'shish oson.

## O'zingizga moslashtirish

Deyarli hamma narsa `settings.py` faylida bitta joyda. Masalan:

- `PLAYER_SPEED`, `PLAYER_MAX_HEALTH` — o'yinchini tezroq/chidamliroq qilish.
- `WAVE_ENEMY_BASE_COUNT`, `BOSS_WAVE_INTERVAL` — to'lqinlarni zichroq yoki bossni tez-tez chiqarish.
- `POWERUP_DROP_CHANCE` — kuchaytirgichlar ko'proq/kamroq tushishi.
- `SCREEN_WIDTH`, `SCREEN_HEIGHT` — oyna o'lchami.

Yangi dushman turi qo'shmoqchi bo'lsangiz, `enemy.py`dagi `Enemy` klassidan meros oluvchi yangi klass yozib, `main.py`ning `_spawn_enemy` metodiga qo'shsangiz bo'ldi.

## Keyingi qadamlar uchun g'oyalar

- O'z rasmlaringiz (sprite)ni qo'shish — hozir kemalar geometrik shakllar bilan chizilgan.
- Yangi dushman naqshlari yoki ikkinchi boss turi.
- Ball uchup chiquvchi raqamlar ("+100") animatsiyasi.
- Qiyinchilik darajasini tanlash menyusi (Oson/O'rta/Qiyin).

Yoqimli o'yin! 🎮

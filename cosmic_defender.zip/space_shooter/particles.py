"""Small particle system used for explosions and hit sparks."""
import math
import random
import pygame


class Particle:
    __slots__ = ("x", "y", "vx", "vy", "life", "max_life", "color", "size")

    def __init__(self, x, y, vx, vy, life, color, size):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.life = life
        self.max_life = life
        self.color = color
        self.size = size

    def update(self, dt):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.vx *= 0.94
        self.vy *= 0.94
        self.life -= dt

    def draw(self, surface):
        if self.life <= 0:
            return
        ratio = max(0.0, self.life / self.max_life)
        size = max(1, round(self.size * ratio))
        color = (
            min(255, max(0, int(self.color[0]))),
            min(255, max(0, int(self.color[1]))),
            min(255, max(0, int(self.color[2]))),
        )
        pygame.draw.circle(surface, color, (round(self.x), round(self.y)), size)


class ParticleSystem:
    def __init__(self):
        self.particles = []

    def explosion(self, x, y, color, count=24, speed_range=(50, 240),
                  life_range=(0.25, 0.6), size_range=(2, 5)):
        for _ in range(count):
            angle = random.uniform(0, math.tau)
            speed = random.uniform(*speed_range)
            vx = math.cos(angle) * speed
            vy = math.sin(angle) * speed
            life = random.uniform(*life_range)
            size = random.uniform(*size_range)
            self.particles.append(Particle(x, y, vx, vy, life, color, size))

    def spark(self, x, y, color):
        self.explosion(x, y, color, count=6, speed_range=(20, 90),
                        life_range=(0.12, 0.28), size_range=(1, 3))

    def update(self, dt):
        for p in self.particles:
            p.update(dt)
        self.particles = [p for p in self.particles if p.life > 0]

    def draw(self, surface):
        for p in self.particles:
            p.draw(surface)

    def clear(self):
        self.particles.clear()

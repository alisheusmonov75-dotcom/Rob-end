"""Central place for every tunable constant in the game.
Change numbers here to reshape how the game feels."""

# --- Screen ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 700
FPS = 60
TITLE = "Cosmic Defender"

# --- Colors (R, G, B) ---
BLACK = (5, 5, 18)
WHITE = (240, 240, 245)
RED = (255, 70, 70)
GREEN = (80, 255, 140)
BLUE = (70, 160, 255)
YELLOW = (255, 220, 70)
PURPLE = (190, 90, 255)
CYAN = (90, 225, 255)
ORANGE = (255, 150, 60)
GRAY = (150, 150, 165)
DARK_GRAY = (35, 35, 48)

# --- Player ---
PLAYER_SPEED = 6.5
PLAYER_MAX_HEALTH = 100
PLAYER_FIRE_COOLDOWN = 220        # ms between shots (normal)
PLAYER_RAPID_COOLDOWN = 100       # ms between shots (rapid-fire power-up)
PLAYER_START_LIVES = 3
PLAYER_INVULN_TIME = 1500         # ms of invulnerability after taking a hit
PLAYER_RESPAWN_INVULN_TIME = 2200
PLAYER_HITBOX_RADIUS = 14
PLAYER_BULLET_SPEED = 11
BULLET_DAMAGE = 10

# --- Enemies ---
ENEMY_BASE_SPEED = 1.6
WAVE_ENEMY_BASE_COUNT = 5
BOSS_WAVE_INTERVAL = 5

# --- Power-ups ---
POWERUP_DROP_CHANCE = 0.22
POWERUP_FALL_SPEED = 2.5
POWERUP_DURATION = 8000  # ms an active power-up lasts

# --- Background ---
STAR_LAYER_COUNTS = (60, 35, 18)

# --- High scores ---
HIGHSCORE_FILE = "highscores.json"
MAX_HIGHSCORES = 5

"""Cosmic Defender - a top-down space shooter.
Run with:  python main.py
"""
import sys
import random
import pygame

pygame.mixer.pre_init(frequency=44100, size=-16, channels=1, buffer=512)
pygame.init()

from settings import (
    SCREEN_WIDTH, SCREEN_HEIGHT, FPS, TITLE, BLACK, WHITE, YELLOW, RED, CYAN, GRAY,
    WAVE_ENEMY_BASE_COUNT, BOSS_WAVE_INTERVAL, POWERUP_DROP_CHANCE,
    PLAYER_START_LIVES, PLAYER_RESPAWN_INVULN_TIME,
)
from player import Player
from enemy import Enemy, ZigzagEnemy, FastEnemy, BossEnemy
from powerup import PowerUp, POWERUP_TYPES
from particles import ParticleSystem
from background import Starfield
from sound_manager import SoundManager
from highscores import load_highscores, save_highscore
from ui import draw_hud, draw_center_text

MENU, PLAYING, PAUSED, GAME_OVER = "menu", "playing", "paused", "game_over"


class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption(TITLE)
        self.clock = pygame.time.Clock()

        self.fonts = {
            "small": pygame.font.SysFont("consolas,couriernew,monospace", 18),
            "medium": pygame.font.SysFont("consolas,couriernew,monospace", 26, bold=True),
            "large": pygame.font.SysFont("consolas,couriernew,monospace", 50, bold=True),
        }

        self.sound = SoundManager()
        self.starfield = Starfield()
        self.state = MENU
        self.highscores = load_highscores()
        self.reset_game()

    def reset_game(self):
        self.player = Player()
        self.lives = PLAYER_START_LIVES
        self.enemies = []
        self.player_bullets = []
        self.enemy_bullets = []
        self.powerups = []
        self.particles = ParticleSystem()
        self.score = 0
        self.wave = 0
        self.enemies_to_spawn = 0
        self.spawn_timer = 0
        self.boss = None
        self.wave_announce_timer = 0
        self.new_highscore = False
        self.start_next_wave()

    def start_next_wave(self):
        self.wave += 1
        self.wave_announce_timer = 1600
        self.sound.play("wave")
        if self.wave % BOSS_WAVE_INTERVAL == 0:
            self.boss = BossEnemy(SCREEN_WIDTH / 2, -80, self.wave)
            self.enemies_to_spawn = 0
        else:
            self.enemies_to_spawn = WAVE_ENEMY_BASE_COUNT + self.wave
            self.spawn_timer = 400

    # ---------------- Events ----------------
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if self.state == PLAYING:
                        self.state = PAUSED
                    elif self.state == PAUSED:
                        self.state = PLAYING
                    else:
                        pygame.quit()
                        sys.exit()
                elif event.key == pygame.K_p and self.state in (PLAYING, PAUSED):
                    self.state = PAUSED if self.state == PLAYING else PLAYING
                elif event.key == pygame.K_RETURN:
                    if self.state in (MENU, GAME_OVER):
                        self.reset_game()
                        self.state = PLAYING

    # ---------------- Update ----------------
    def update(self, dt_ms):
        dt = dt_ms / 1000
        self.starfield.update(dt)

        if self.state != PLAYING:
            return

        keys = pygame.key.get_pressed()
        self.player.handle_input(keys, dt_ms)
        self.player.update(dt_ms)

        if keys[pygame.K_SPACE] and self.player.can_fire():
            self.player_bullets.extend(self.player.shoot())
            self.sound.play("shoot")

        if self.wave_announce_timer > 0:
            self.wave_announce_timer -= dt_ms

        self._update_spawning(dt_ms)
        self._update_entities(dt_ms, dt)
        self._update_collisions()
        self.particles.update(dt)

        if self.player.health <= 0:
            self._handle_player_death()

        if not self.enemies and not self.boss and self.enemies_to_spawn <= 0:
            self.start_next_wave()

    def _update_spawning(self, dt_ms):
        if self.enemies_to_spawn > 0:
            self.spawn_timer -= dt_ms
            if self.spawn_timer <= 0:
                self._spawn_enemy()
                self.enemies_to_spawn -= 1
                self.spawn_timer = max(300, 900 - self.wave * 15)

    def _spawn_enemy(self):
        x = random.uniform(40, SCREEN_WIDTH - 40)
        roll = random.random()
        cls = Enemy if roll < 0.5 else (ZigzagEnemy if roll < 0.8 else FastEnemy)
        self.enemies.append(cls(x, -30, self.wave))

    def _update_entities(self, dt_ms, dt):
        for b in self.player_bullets:
            b.update(dt)
        self.player_bullets = [b for b in self.player_bullets if b.alive]

        for b in self.enemy_bullets:
            b.update(dt)
        self.enemy_bullets = [b for b in self.enemy_bullets if b.alive]

        for e in self.enemies:
            e.update(dt_ms, dt)
            shot = e.try_shoot(self.player.x, self.player.y)
            if shot:
                self.enemy_bullets.append(shot)
                self.sound.play("enemy_shoot")
        self.enemies = [e for e in self.enemies if e.alive_on_screen and e.health > 0]

        if self.boss:
            self.boss.update(dt_ms, dt)
            shot = self.boss.try_shoot(self.player.x, self.player.y)
            if shot:
                self.enemy_bullets.append(shot)
            if self.boss.health <= 0:
                self._defeat_boss()

        for p in self.powerups:
            p.update(dt)
        self.powerups = [p for p in self.powerups if p.alive]

    def _update_collisions(self):
        # player bullets vs enemies (and boss)
        for bullet in self.player_bullets[:]:
            targets = list(self.enemies)
            if self.boss:
                targets.append(self.boss)
            for enemy in targets:
                if bullet.rect.colliderect(enemy.rect):
                    enemy.health -= bullet.damage
                    self.particles.spark(bullet.x, bullet.y, enemy.color)
                    if enemy.health <= 0:
                        if enemy is not self.boss:
                            self._kill_enemy(enemy)
                    else:
                        self.sound.play("hit")
                    if bullet in self.player_bullets:
                        self.player_bullets.remove(bullet)
                    break

        # enemy bullets vs player
        for bullet in self.enemy_bullets[:]:
            if bullet.rect.colliderect(self.player.rect):
                if self.player.take_hit(bullet.damage):
                    self.sound.play("hit")
                    self.particles.spark(bullet.x, bullet.y, RED)
                if bullet in self.enemy_bullets:
                    self.enemy_bullets.remove(bullet)

        # enemies ramming the player
        for enemy in self.enemies[:]:
            if enemy.rect.colliderect(self.player.rect):
                if self.player.take_hit(20):
                    self.sound.play("hit")
                self._kill_enemy(enemy, award_score=False)

        # power-ups vs player
        for p in self.powerups[:]:
            if p.rect.colliderect(self.player.rect):
                self.player.apply_powerup(p.kind, p.duration)
                self.sound.play("powerup")
                self.powerups.remove(p)

    def _kill_enemy(self, enemy, award_score=True):
        self.particles.explosion(enemy.x, enemy.y, enemy.color)
        self.sound.play("explosion")
        if award_score:
            self.score += enemy.score_value
        if random.random() < POWERUP_DROP_CHANCE:
            kind = random.choice(list(POWERUP_TYPES.keys()))
            self.powerups.append(PowerUp(enemy.x, enemy.y, kind))
        if enemy in self.enemies:
            self.enemies.remove(enemy)

    def _defeat_boss(self):
        self.particles.explosion(self.boss.x, self.boss.y, self.boss.color,
                                  count=60, speed_range=(60, 300), life_range=(0.4, 0.9))
        self.sound.play("explosion")
        self.score += self.boss.score_value
        self.boss = None

    def _handle_player_death(self):
        self.lives -= 1
        self.particles.explosion(self.player.x, self.player.y, CYAN, count=40)
        if self.lives <= 0:
            self.sound.play("game_over")
            before = self.highscores
            self.highscores = save_highscore(self.score)
            self.new_highscore = bool(self.highscores) and self.score == self.highscores[0] and self.highscores != before
            self.state = GAME_OVER
        else:
            self.player.health = self.player.max_health
            self.player.x = SCREEN_WIDTH / 2
            self.player.y = SCREEN_HEIGHT - 90
            self.player.invuln_timer = PLAYER_RESPAWN_INVULN_TIME

    # ---------------- Draw ----------------
    def draw(self):
        self.screen.fill(BLACK)
        self.starfield.draw(self.screen)

        if self.state == MENU:
            self._draw_menu()
        else:
            self._draw_gameplay()
            if self.state == PAUSED:
                self._draw_pause()
            elif self.state == GAME_OVER:
                self._draw_game_over()

        pygame.display.flip()

    def _draw_gameplay(self):
        for b in self.player_bullets:
            b.draw(self.screen)
        for b in self.enemy_bullets:
            b.draw(self.screen)
        for e in self.enemies:
            e.draw(self.screen)
        if self.boss:
            self.boss.draw(self.screen)
        for p in self.powerups:
            p.draw(self.screen, self.fonts["small"])
        self.particles.draw(self.screen)
        self.player.draw(self.screen)

        draw_hud(self.screen, self.fonts, self.player, self.score, self.wave, boss=self.boss)

        for i in range(self.lives):
            cx, cy = SCREEN_WIDTH - 24 - i * 26, 70
            pygame.draw.polygon(self.screen, CYAN, [(cx, cy - 8), (cx - 7, cy + 7), (cx + 7, cy + 7)])

        if self.wave_announce_timer > 0:
            is_boss_wave = self.wave % BOSS_WAVE_INTERVAL == 0
            label = "BOSS!" if is_boss_wave else f"{self.wave}-TO'LQIN"
            draw_center_text(self.screen, self.fonts["large"], label, 140, YELLOW)

    def _draw_menu(self):
        draw_center_text(self.screen, self.fonts["large"], "COSMIC DEFENDER", 170, CYAN)
        draw_center_text(self.screen, self.fonts["medium"], "Boshlash uchun ENTER bosing", 250, WHITE)
        draw_center_text(self.screen, self.fonts["small"],
                          "Yurish: strelkalar / WASD   Otish: BO'SHLIQ   Pauza: P", 290, GRAY)
        if self.highscores:
            draw_center_text(self.screen, self.fonts["medium"], "Rekordlar", 370, YELLOW)
            for i, s in enumerate(self.highscores):
                draw_center_text(self.screen, self.fonts["small"], f"{i + 1}. {s}", 405 + i * 26, WHITE)

    def _draw_pause(self):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        self.screen.blit(overlay, (0, 0))
        draw_center_text(self.screen, self.fonts["large"], "PAUZA", SCREEN_HEIGHT // 2 - 20, WHITE)
        draw_center_text(self.screen, self.fonts["small"], "Davom etish uchun P bosing", SCREEN_HEIGHT // 2 + 30, GRAY)

    def _draw_game_over(self):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 190))
        self.screen.blit(overlay, (0, 0))
        draw_center_text(self.screen, self.fonts["large"], "O'YIN TUGADI", SCREEN_HEIGHT // 2 - 90, RED)
        draw_center_text(self.screen, self.fonts["medium"], f"Ball: {self.score}", SCREEN_HEIGHT // 2 - 30, WHITE)
        if self.new_highscore:
            draw_center_text(self.screen, self.fonts["medium"], "Yangi rekord!", SCREEN_HEIGHT // 2 + 10, YELLOW)
        draw_center_text(self.screen, self.fonts["small"], "Qayta boshlash uchun ENTER bosing", SCREEN_HEIGHT // 2 + 60, GRAY)

    # ---------------- Main loop ----------------
    def run(self):
        while True:
            dt_ms = self.clock.tick(FPS)
            dt_ms = min(dt_ms, 50)  # clamp huge stalls so nothing teleports
            self.handle_events()
            self.update(dt_ms)
            self.draw()


if __name__ == "__main__":
    Game().run()

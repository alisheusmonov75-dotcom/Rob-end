"""Enemy ships: a basic grunt, a zigzagger, a fast interceptor, and a boss."""
import math
import random
import pygame
from settings import SCREEN_WIDTH, SCREEN_HEIGHT, ENEMY_BASE_SPEED, RED, ORANGE, PURPLE, GRAY, WHITE
from bullet import Bullet


class Enemy:
    kind = "basic"
    radius = 16
    max_health = 20
    score_value = 100
    color = RED

    def __init__(self, x, y, wave=1):
        self.x = x
        self.y = y
        self.health = self.max_health + (wave - 1) * 2
        self.max_health = self.health
        self.speed = ENEMY_BASE_SPEED + wave * 0.05
        self.shoot_timer = random.uniform(800, 2200)
        self.age = 0.0

    def update(self, dt_ms, dt):
        self.y += self.speed * dt * 60
        self.age += dt_ms
        self.shoot_timer -= dt_ms

    def try_shoot(self, target_x, target_y):
        if self.shoot_timer <= 0:
            self.shoot_timer = random.uniform(1400, 2600)
            dx = target_x - self.x
            dy = target_y - self.y
            dist = max(1.0, math.hypot(dx, dy))
            speed = 5.0
            return Bullet(self.x, self.y, dx / dist * speed, dy / dist * speed,
                          damage=8, color=ORANGE, radius=4, owner="enemy")
        return None

    @property
    def alive_on_screen(self):
        return self.y - self.radius < SCREEN_HEIGHT + 40

    @property
    def rect(self):
        r = self.radius
        return pygame.Rect(self.x - r, self.y - r, r * 2, r * 2)

    def draw(self, surface):
        pos = (round(self.x), round(self.y))
        pygame.draw.circle(surface, self.color, pos, self.radius)
        pygame.draw.circle(surface, WHITE, pos, self.radius, 2)
        self._draw_health(surface)

    def _draw_health(self, surface):
        if self.health >= self.max_health:
            return
        w = self.radius * 2
        ratio = max(0, self.health / self.max_health)
        x0 = self.x - self.radius
        y0 = self.y - self.radius - 8
        pygame.draw.rect(surface, (60, 20, 20), (x0, y0, w, 4))
        pygame.draw.rect(surface, (80, 230, 90), (x0, y0, w * ratio, 4))


class ZigzagEnemy(Enemy):
    kind = "zigzag"
    radius = 14
    max_health = 15
    score_value = 150
    color = PURPLE

    def __init__(self, x, y, wave=1):
        super().__init__(x, y, wave)
        self.base_x = x
        self.amplitude = random.uniform(60, 140)
        self.freq = random.uniform(1.4, 2.2)

    def update(self, dt_ms, dt):
        super().update(dt_ms, dt)
        self.x = self.base_x + math.sin(self.age / 1000 * self.freq) * self.amplitude


class FastEnemy(Enemy):
    kind = "fast"
    radius = 11
    max_health = 8
    score_value = 200
    color = GRAY

    def __init__(self, x, y, wave=1):
        super().__init__(x, y, wave)
        self.speed = ENEMY_BASE_SPEED * 2.6 + wave * 0.08
        self.shoot_timer = float("inf")  # never shoots

    def try_shoot(self, target_x, target_y):
        return None


class BossEnemy(Enemy):
    kind = "boss"
    radius = 46
    score_value = 1500
    color = (220, 40, 90)

    def __init__(self, x, y, wave=1):
        self.max_health = 260 + wave * 30
        self.health = self.max_health
        self.x = x
        self.y = -80
        self.target_y = 110
        self.speed = 1.8
        self.age = 0.0
        self.shoot_timer = 900
        self.direction = 1
        self.entering = True

    def update(self, dt_ms, dt):
        self.age += dt_ms
        if self.entering:
            self.y += self.speed * dt * 60
            if self.y >= self.target_y:
                self.y = self.target_y
                self.entering = False
        else:
            self.x += self.direction * 1.6 * dt * 60
            if self.x < 90 or self.x > SCREEN_WIDTH - 90:
                self.direction *= -1
        self.shoot_timer -= dt_ms

    def try_shoot(self, target_x, target_y):
        if self.entering or self.shoot_timer > 0:
            return None
        self.shoot_timer = random.uniform(450, 750)
        dx = target_x - self.x
        dy = target_y - self.y
        dist = max(1.0, math.hypot(dx, dy))
        speed = 6.0
        return Bullet(self.x, self.y, dx / dist * speed, dy / dist * speed,
                      damage=12, color=(255, 80, 140), radius=5, owner="enemy")

    @property
    def alive_on_screen(self):
        return True  # the boss stays until defeated, it never "escapes"

    def draw(self, surface):
        pos = (round(self.x), round(self.y))
        pygame.draw.circle(surface, self.color, pos, self.radius)
        pygame.draw.circle(surface, WHITE, pos, self.radius, 3)
        inner_color = tuple(min(255, c + 50) for c in self.color)
        pygame.draw.circle(surface, inner_color, pos, self.radius - 16)

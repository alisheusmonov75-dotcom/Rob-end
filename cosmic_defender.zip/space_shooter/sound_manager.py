"""Every sound effect is synthesized on the fly with numpy, so the game
needs no external audio files. If numpy or the audio device isn't
available, the game simply runs silently instead of crashing."""
import pygame

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

SAMPLE_RATE = 44100


class SoundManager:
    def __init__(self):
        self.enabled = False
        self.sounds = {}
        if not NUMPY_AVAILABLE:
            return
        try:
            if pygame.mixer.get_init() is None:
                pygame.mixer.init(frequency=SAMPLE_RATE, size=-16, channels=1)
            self.enabled = True
            self._build_sounds()
        except pygame.error:
            self.enabled = False

    def _tone(self, freq, duration, volume=0.4, wave="sine"):
        n = int(SAMPLE_RATE * duration)
        t = np.linspace(0, duration, n, False)
        if wave == "square":
            data = np.sign(np.sin(freq * t * 2 * np.pi))
        elif wave == "noise":
            data = np.random.uniform(-1, 1, n)
        else:
            data = np.sin(freq * t * 2 * np.pi)
        envelope = np.linspace(1, 0, n) ** 1.5
        data = data * envelope * volume
        audio = (data * 32767).astype(np.int16)
        return pygame.sndarray.make_sound(np.ascontiguousarray(audio))

    def _sweep(self, f_start, f_end, duration, volume=0.4):
        n = int(SAMPLE_RATE * duration)
        t = np.linspace(0, duration, n, False)
        freq = np.linspace(f_start, f_end, n)
        phase = np.cumsum(freq) / SAMPLE_RATE * 2 * np.pi
        data = np.sin(phase)
        envelope = np.linspace(1, 0, n) ** 1.2
        data = data * envelope * volume
        audio = (data * 32767).astype(np.int16)
        return pygame.sndarray.make_sound(np.ascontiguousarray(audio))

    def _build_sounds(self):
        self.sounds["shoot"] = self._tone(880, 0.08, volume=0.15, wave="square")
        self.sounds["enemy_shoot"] = self._tone(440, 0.08, volume=0.12, wave="square")
        self.sounds["explosion"] = self._tone(120, 0.35, volume=0.35, wave="noise")
        self.sounds["hit"] = self._tone(200, 0.15, volume=0.25, wave="noise")
        self.sounds["powerup"] = self._sweep(400, 1000, 0.25, volume=0.25)
        self.sounds["game_over"] = self._sweep(500, 80, 0.9, volume=0.3)
        self.sounds["wave"] = self._sweep(300, 700, 0.3, volume=0.2)

    def play(self, name):
        if self.enabled and name in self.sounds:
            try:
                self.sounds[name].play()
            except pygame.error:
                pass

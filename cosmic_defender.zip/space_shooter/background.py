"""Scrolling parallax starfield drawn behind everything else."""
import random
import pygame
from settings import SCREEN_WIDTH, SCREEN_HEIGHT, STAR_LAYER_COUNTS


class Starfield:
    def __init__(self):
        self.layers = []
        speeds = (20, 45, 90)
        sizes = (1, 2, 3)
        brightness = (90, 160, 230)
        for count, speed, size, bright in zip(STAR_LAYER_COUNTS, speeds, sizes, brightness):
            stars = [[random.uniform(0, SCREEN_WIDTH), random.uniform(0, SCREEN_HEIGHT)]
                     for _ in range(count)]
            color = (bright, bright, min(255, bright + 20))
            self.layers.append({"stars": stars, "speed": speed, "size": size, "color": color})

    def update(self, dt):
        for layer in self.layers:
            for star in layer["stars"]:
                star[1] += layer["speed"] * dt
                if star[1] > SCREEN_HEIGHT:
                    star[1] = 0
                    star[0] = random.uniform(0, SCREEN_WIDTH)

    def draw(self, surface):
        for layer in self.layers:
            color = layer["color"]
            size = layer["size"]
            for star in layer["stars"]:
                pygame.draw.circle(surface, color, (int(star[0]), int(star[1])), size)

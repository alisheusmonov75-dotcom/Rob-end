"""Power-ups dropped by defeated enemies."""
import pygame
from settings import SCREEN_HEIGHT, POWERUP_FALL_SPEED, POWERUP_DURATION, GREEN, CYAN, PURPLE, YELLOW, BLUE

POWERUP_TYPES = {
    "health": {"color": GREEN, "label": "+"},
    "rapid": {"color": YELLOW, "label": "R"},
    "spread": {"color": PURPLE, "label": "S"},
    "shield": {"color": CYAN, "label": "O"},
    "speed": {"color": BLUE, "label": ">"},
}


class PowerUp:
    def __init__(self, x, y, kind):
        self.x = x
        self.y = y
        self.kind = kind
        self.radius = 12
        self.duration = POWERUP_DURATION

    def update(self, dt):
        self.y += POWERUP_FALL_SPEED * dt * 60

    @property
    def alive(self):
        return self.y - self.radius < SCREEN_HEIGHT + 20

    @property
    def rect(self):
        r = self.radius
        return pygame.Rect(self.x - r, self.y - r, r * 2, r * 2)

    def draw(self, surface, font):
        info = POWERUP_TYPES[self.kind]
        pos = (round(self.x), round(self.y))
        pygame.draw.circle(surface, info["color"], pos, self.radius)
        pygame.draw.circle(surface, (255, 255, 255), pos, self.radius, 2)
        label = font.render(info["label"], True, (10, 10, 15))
        surface.blit(label, label.get_rect(center=pos))

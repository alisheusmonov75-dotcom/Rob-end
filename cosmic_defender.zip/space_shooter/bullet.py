"""A single projectile fired by the player or by an enemy."""
import pygame
from settings import SCREEN_HEIGHT


class Bullet:
    def __init__(self, x, y, vx, vy, damage, color, radius=4, owner="player"):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.damage = damage
        self.color = color
        self.radius = radius
        self.owner = owner  # "player" or "enemy"

    def update(self, dt):
        self.x += self.vx * dt * 60
        self.y += self.vy * dt * 60

    @property
    def alive(self):
        return -20 <= self.y <= SCREEN_HEIGHT + 20

    @property
    def rect(self):
        r = self.radius
        return pygame.Rect(self.x - r, self.y - r, r * 2, r * 2)

    def draw(self, surface):
        pos = (round(self.x), round(self.y))
        pygame.draw.circle(surface, self.color, pos, self.radius)
        glow = tuple(min(255, c + 60) for c in self.color)
        pygame.draw.circle(surface, glow, pos, max(1, self.radius - 2))

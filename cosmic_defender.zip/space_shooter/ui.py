"""HUD and on-screen text helpers."""
import pygame
from settings import SCREEN_WIDTH, SCREEN_HEIGHT, WHITE, RED, GREEN, YELLOW, DARK_GRAY
from powerup import POWERUP_TYPES


def draw_hud(surface, fonts, player, score, wave, boss=None):
    small = fonts["small"]
    med = fonts["medium"]

    # Health bar
    bar_w, bar_h = 200, 18
    x, y = 16, 16
    pygame.draw.rect(surface, DARK_GRAY, (x - 2, y - 2, bar_w + 4, bar_h + 4), border_radius=4)
    ratio = max(0, player.health / player.max_health)
    color = GREEN if ratio > 0.5 else (YELLOW if ratio > 0.25 else RED)
    pygame.draw.rect(surface, color, (x, y, bar_w * ratio, bar_h), border_radius=3)
    hp_text = small.render(f"Jon: {max(0, int(player.health))}/{player.max_health}", True, WHITE)
    surface.blit(hp_text, (x + 6, y + 1))

    # Score & wave (top right)
    score_text = med.render(f"Ball: {score}", True, WHITE)
    surface.blit(score_text, (SCREEN_WIDTH - score_text.get_width() - 16, 14))
    wave_text = small.render(f"To'lqin: {wave}", True, YELLOW)
    surface.blit(wave_text, (SCREEN_WIDTH - wave_text.get_width() - 16, 44))

    # Active power-up icons
    icon_x, icon_y = x, y + bar_h + 14
    for kind, remaining in player.power_timers.items():
        if remaining > 0:
            info = POWERUP_TYPES[kind]
            center = (icon_x + 10, icon_y + 10)
            pygame.draw.circle(surface, info["color"], center, 10)
            label = small.render(info["label"], True, (10, 10, 15))
            surface.blit(label, label.get_rect(center=center))
            icon_x += 26

    # Boss health bar (bottom of screen)
    if boss is not None:
        bw = SCREEN_WIDTH - 120
        bx, by = 60, SCREEN_HEIGHT - 34
        pygame.draw.rect(surface, DARK_GRAY, (bx - 2, by - 2, bw + 4, 16), border_radius=4)
        bratio = max(0, boss.health / boss.max_health)
        pygame.draw.rect(surface, (220, 40, 90), (bx, by, bw * bratio, 12), border_radius=3)
        label = small.render("BOSS", True, WHITE)
        surface.blit(label, (bx, by - 18))


def draw_center_text(surface, font, text, y, color=WHITE):
    render = font.render(text, True, color)
    rect = render.get_rect(center=(SCREEN_WIDTH // 2, y))
    surface.blit(render, rect)
    return rect

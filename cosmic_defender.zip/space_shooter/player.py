"""The player-controlled ship."""
import math
import pygame
from settings import (
    SCREEN_WIDTH, SCREEN_HEIGHT, PLAYER_SPEED, PLAYER_MAX_HEALTH,
    PLAYER_FIRE_COOLDOWN, PLAYER_RAPID_COOLDOWN, PLAYER_INVULN_TIME,
    PLAYER_HITBOX_RADIUS, PLAYER_BULLET_SPEED, BULLET_DAMAGE,
    CYAN, WHITE, YELLOW, GREEN,
)
from bullet import Bullet


class Player:
    def __init__(self):
        self.x = SCREEN_WIDTH / 2
        self.y = SCREEN_HEIGHT - 90
        self.health = PLAYER_MAX_HEALTH
        self.max_health = PLAYER_MAX_HEALTH
        self.speed = PLAYER_SPEED
        self.radius = PLAYER_HITBOX_RADIUS
        self.fire_cooldown = PLAYER_FIRE_COOLDOWN
        self.fire_timer = 0.0
        self.invuln_timer = 0.0

        # Timed power-ups: name -> remaining ms
        self.power_timers = {"rapid": 0.0, "spread": 0.0, "shield": 0.0, "speed": 0.0}

    @property
    def is_invulnerable(self):
        return self.invuln_timer > 0

    @property
    def rect(self):
        r = self.radius
        return pygame.Rect(self.x - r, self.y - r, r * 2, r * 2)

    def take_hit(self, amount):
        """Apply incoming damage. Returns True if damage actually landed."""
        if self.is_invulnerable:
            return False
        if self.power_timers["shield"] > 0:
            self.power_timers["shield"] = 0
            self.invuln_timer = PLAYER_INVULN_TIME
            return False
        self.health -= amount
        self.invuln_timer = PLAYER_INVULN_TIME
        return True

    def apply_powerup(self, kind, duration):
        if kind == "health":
            self.health = min(self.max_health, self.health + 35)
        else:
            self.power_timers[kind] = duration

    def handle_input(self, keys, dt_ms):
        dt = dt_ms / 1000
        speed = self.speed * (1.5 if self.power_timers["speed"] > 0 else 1.0)
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.x -= speed * dt * 60
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.x += speed * dt * 60
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            self.y -= speed * dt * 60
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            self.y += speed * dt * 60

        self.x = max(self.radius, min(SCREEN_WIDTH - self.radius, self.x))
        self.y = max(self.radius, min(SCREEN_HEIGHT - self.radius, self.y))

    def update(self, dt_ms):
        if self.fire_timer > 0:
            self.fire_timer -= dt_ms
        if self.invuln_timer > 0:
            self.invuln_timer -= dt_ms
        for k in self.power_timers:
            if self.power_timers[k] > 0:
                self.power_timers[k] = max(0.0, self.power_timers[k] - dt_ms)

    def can_fire(self):
        return self.fire_timer <= 0

    def shoot(self):
        cooldown = PLAYER_RAPID_COOLDOWN if self.power_timers["rapid"] > 0 else self.fire_cooldown
        self.fire_timer = cooldown
        bullets = []
        angles = (-0.28, -0.12, 0, 0.12, 0.28) if self.power_timers["spread"] > 0 else (0,)
        for a in angles:
            vx = math.sin(a) * PLAYER_BULLET_SPEED
            vy = -math.cos(a) * PLAYER_BULLET_SPEED
            bullets.append(Bullet(self.x, self.y - self.radius, vx, vy,
                                   damage=BULLET_DAMAGE, color=YELLOW, radius=4, owner="player"))
        return bullets

    def draw(self, surface):
        if self.is_invulnerable and (pygame.time.get_ticks() // 100) % 2 == 0:
            return  # blink while invulnerable
        points = [
            (self.x, self.y - 18),
            (self.x - 14, self.y + 14),
            (self.x, self.y + 6),
            (self.x + 14, self.y + 14),
        ]
        pygame.draw.polygon(surface, CYAN, points)
        pygame.draw.polygon(surface, WHITE, points, 2)

        if self.power_timers["shield"] > 0:
            pygame.draw.circle(surface, GREEN, (round(self.x), round(self.y)), self.radius + 10, 2)

        flame_h = 8 + (pygame.time.get_ticks() % 100) / 20
        pygame.draw.polygon(surface, YELLOW, [
            (self.x - 5, self.y + 12),
            (self.x + 5, self.y + 12),
            (self.x, self.y + 12 + flame_h),
        ])
